/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;
import Classes.MailSender;
import Classes.ScreenshotManager;
import java.io.IOException;
import monitoringemployees.MonitoringEmployees;
import java.awt.AWTException;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.io.File;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.Timer;
/**
 *
 * @author bherz
 */
public class Utama extends javax.swing.JFrame {
    int time = 10;
    int actualTime = 10;
    int msgTimeCounter = -1;
    public static int ticks = 0;
    Timer t;
    Thread manager;
    public static String path = new File("").getAbsolutePath();
    JFileChooser fc;
    public static boolean sending = false;
    boolean sendingBackground = false;
    Date startingDate = new GregorianCalendar().getTime();    
    Integer historyId = 0;
    public static HashMap history = new HashMap();    
    /**
     * Creates new form Utama
     */
    public Utama() {
         //<editor-fold defaultstate="collapsed" desc="Look and feel">
        try {
            javax.swing.UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");//info.getClassName()
        } catch (Exception ex) {
            try {
                for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        javax.swing.UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } catch (Exception ex1) {
            }
        }
        //</editor-fold>
        initComponents();
        ssPath.setBackground(Color.WHITE);
        ssPath.setText(path);
        message.setText("       ");
        t = new Timer(1000, new ActionListener (){
            @Override
            public void actionPerformed(ActionEvent e){
                ticks++;
                if(time==0){
                    message.setForeground(new Color(0, 201, 77));
                    message.setText("Captured!");
                    setTitle("Captured!");
                    msgTimeCounter = 0;
                    time = actualTime;
                    if(!path.equals(""))
                        path = path+"/";
                    GregorianCalendar cal = new GregorianCalendar();
                    String screenshotName = 
                            cal.get(GregorianCalendar.HOUR_OF_DAY)+"_"+
                            (cal.get(GregorianCalendar.MINUTE) >=10 ? cal.get(GregorianCalendar.MINUTE) : ("0"+cal.get(GregorianCalendar.MINUTE))) + "_"+
                            (cal.get(GregorianCalendar.SECOND) >= 10 ? cal.get(GregorianCalendar.SECOND) : "0"+cal.get(GregorianCalendar.SECOND))+" "+
                            (cal.get(GregorianCalendar.MONTH)+1)+"-"+cal.get(GregorianCalendar.DAY_OF_MONTH)+"-"+cal.get(GregorianCalendar.YEAR)+".jpg";
                    manager = new ScreenshotManager(path+screenshotName);
                    manager.start();
                    sendingBackground = true;
                    historyId++;
                    history.put(historyId, new Object[]{cal.getTime(), screenshotName});
                }else{
                    time--;
                    if(time==0){
                        setTitle("Captured...");
                    }else{
                        String m = time/60 >=10 ? ""+time/60 : "0"+time/60;
                        String s = time%60 >= 10 ? ""+time%60 : "0"+time%60;
                        setTitle(m +":"+s);
                    }
                }
                if(msgTimeCounter != -1){
                   msgTimeCounter ++;
                   if(msgTimeCounter == 4){
                       msgTimeCounter = -1;
                       message.setText("        ");
                    }
                }
                remainingText.setText("Next capture will be taken in "+time+" seconds");
            }
        });
        class windowsCloser extends WindowAdapter{
            @Override
            public void windowClosing(java.awt.event.WindowEvent e){
                pauseBtn.setText("Resume");
                if(sendingBackground){
                    t.stop();
                    remainingText.setText("");
                    message.setForeground(new Color(255, 191, 56));
                    if(manager != null)
                        manager.stop();
                    if(!sending){
                        sending = true;
                        setTitle("Mengirim email...");
                        message.setText("Mengirim email...");
                        new MailSender().start();
                    }
                } else 
                    System.exit(0);
            }
        }
        this.addWindowListener(new windowsCloser());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
           
    @SuppressWarnings("unchecked")
    //Jangan diedit. Untuk form
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        intervalMin = new javax.swing.JSpinner();
        intervalSec = new javax.swing.JSpinner();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        pauseBtn = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        ssPath = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        remainingText = new javax.swing.JLabel();
        message = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem4 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("EmployeeMonitoring v.1.0");
        setBackground(new java.awt.Color(0, 51, 204));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setResizable(false);
        addWindowStateListener(new java.awt.event.WindowStateListener() {
            public void windowStateChanged(java.awt.event.WindowEvent evt) {
                detectMinimize(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel1.setText("Set Screen Capture Interval");

        intervalSec.setValue(Integer.valueOf(10));

        jLabel2.setText("Minutes");

        jLabel3.setText("Seconds");

        jButton1.setText("Set");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                setInterval(evt);
            }
        });

        pauseBtn.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        pauseBtn.setText("Start");
        pauseBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                pause(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setText("Set Screen Capture Path");

        ssPath.setEditable(false);
        ssPath.setFont(new java.awt.Font("Times New Roman", 0, 11)); // NOI18N
        ssPath.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jButton3.setText("...");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                browse(evt);
            }
        });

        remainingText.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        remainingText.setText("Next capture will be taken in 10 seconds");

        message.setForeground(new java.awt.Color(45, 181, 0));
        message.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        message.setText("               ");

        jMenuBar1.setMaximumSize(new java.awt.Dimension(60, 32769));
        jMenuBar1.setPreferredSize(new java.awt.Dimension(60, 21));

        jMenu1.setText("File");

        jMenuItem5.setText("Screen Capture Folder");
        jMenuItem5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                openSSFolder(evt);
            }
        });
        jMenu1.add(jMenuItem5);

        jMenuItem1.setText("Set user dan password");
        jMenuItem1.setToolTipText("");
        jMenuItem1.setPreferredSize(new java.awt.Dimension(199, 22));
        jMenuItem1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                setUserPass(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setText("Exit");
        jMenuItem2.setPreferredSize(new java.awt.Dimension(199, 22));
        jMenuItem2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                keluar(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Help");

        jMenuItem4.setText("Tentang Employee Monitor");
        jMenuItem4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                about(evt);
            }
        });
        jMenu2.add(jMenuItem4);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addComponent(pauseBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(intervalMin, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addComponent(jLabel2)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel3)
                                    .addComponent(intervalSec, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(ssPath)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(remainingText)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(message, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(intervalMin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(intervalSec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2))
                .addGap(20, 20, 20)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ssPath, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3))
                .addGap(18, 18, 18)
                .addComponent(remainingText)
                .addGap(3, 3, 3)
                .addComponent(message)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pauseBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void keluar(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_keluar
        // TODO add your handling code here:
        pauseBtn.setText("Resume");
        if(sendingBackground){
            t.stop();
            remainingText.setText("");
            message.setForeground(new Color(255, 191, 56));
            if(manager != null)
                manager.stop();
            if(!sending){
                sending = true;
                setTitle("Mengirim email...");
                message.setText("Mengirim email...");
                new MailSender().start();
            } 
        }else
            System.exit(0);
    }//GEN-LAST:event_keluar

    private void openSSFolder(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_openSSFolder
        // TODO add your handling code here:
        try{
            Desktop.getDesktop().open(new File(path));            
        } catch (IOException ex){}
    }//GEN-LAST:event_openSSFolder

    private void setUserPass(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_setUserPass
        // TODO add your handling code here:
        UserPassManager upm = new UserPassManager();
        JDialog dialog = new JDialog(upm, "Change personal data", true);
        upm.setVisible(false);
        dialog.setContentPane(upm.getContentPane());
        dialog.setBounds(upm.getBounds());
        dialog.setLocationRelativeTo(null);
        dialog.setResizable(false);
        dialog.setVisible(true);
    }//GEN-LAST:event_setUserPass

    private void about(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_about
        // TODO add your handling code here:
        About about = new About();
        JDialog dialog = new JDialog(about, "About EmployeeMonitor...", true);
        about.setVisible(false);
        dialog.setContentPane(about.getContentPane());
        dialog.setBounds(about.getBounds());
        dialog.setLocationRelativeTo(null);
        dialog.setResizable(false);
        dialog.setVisible(true);
    }//GEN-LAST:event_about

    private void detectMinimize(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_detectMinimize
        // TODO add your handling code here:
        if(getState() == 1){
            MonitoringEmployees.p.setVisible(false);
            try{
                final TrayIcon icon = new TrayIcon(Toolkit.getDefaultToolkit().getImage("icon.png") ,"MonitoringEmployees", new PopupMenu("MonitoringEmployees"));
                icon.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e){
                    MonitoringEmployees.p.setVisible(true);
                    java.awt.EventQueue.invokeLater(new Runnable(){
                        @Override
                        public void run(){
                            MonitoringEmployees.p.toFront();
                            MonitoringEmployees.p.repaint();
                            SystemTray.getSystemTray().remove(icon);
                        }
                    });
                    }
                });
                SystemTray.getSystemTray().add(icon);
                icon.displayMessage("EmployeeMonitor", "EmployeeMonitor will still running in background, you can re-open it by clicking this icon",TrayIcon.MessageType.INFO);
            }catch(AWTException ex){
                Logger.getLogger(Utama.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_detectMinimize

    private void setInterval(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_setInterval
        // TODO add your handling code here:
        if(manager != null)
            manager.stop();
        time = ((Integer)intervalMin.getValue() >0 ? ((Integer)intervalMin.getValue() * 60) : 0 );
        time = time + ((Integer)intervalSec.getValue() > 0 ? (Integer)intervalSec.getValue() : 10);
        actualTime = time;
        t.start();
        message.setText("       ");
    }//GEN-LAST:event_setInterval

    private void browse(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_browse
        // TODO add your handling code here:
        fc = new javax.swing.JFileChooser();
        fc.setMultiSelectionEnabled(false);
        fc.setDialogType(javax.swing.JFileChooser.CUSTOM_DIALOG);
        fc.setFileSelectionMode(javax.swing.JFileChooser.DIRECTORIES_ONLY);
        int returnVal = fc.showOpenDialog(Utama.this);
        if(returnVal == javax.swing.JFileChooser.APPROVE_OPTION){
            path = fc.getSelectedFile().getAbsolutePath();
            ssPath.setText(path);        
        }
    }//GEN-LAST:event_browse

    private void pause(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pause
        // TODO add your handling code here:
        if (pauseBtn.getText().equals("Start")){
            time = ((Integer)intervalMin.getValue() > 0 ? ((Integer)intervalMin.getValue() * 60) : 0);
            time = time + ((Integer)intervalSec.getValue() > 0 ? (Integer)intervalSec.getValue() : 10);
            actualTime = time;
            t.start();
            pauseBtn.setText("Pause");
        }else if (pauseBtn.getText().equals("Pause")){
            t.stop();
            pauseBtn.setText("Resume");
            setTitle("Paused...");
        }else{
            t.start();
            pauseBtn.setText("Pause");
            setTitle("Continuing...");
        }    
        message.setText("     ");
    }//GEN-LAST:event_pause

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        //Jangan diedit. Untuk form
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Utama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Utama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Utama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Utama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Utama().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSpinner intervalMin;
    private javax.swing.JSpinner intervalSec;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    public static javax.swing.JLabel message;
    private javax.swing.JButton pauseBtn;
    private javax.swing.JLabel remainingText;
    private javax.swing.JTextField ssPath;
    // End of variables declaration//GEN-END:variables
}
